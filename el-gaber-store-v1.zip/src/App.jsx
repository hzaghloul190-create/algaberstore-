import React, { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft, ArrowUp, CheckCircle2, ChevronDown, Clock3, CreditCard,
  Eye, Facebook, Instagram, LayoutDashboard, Menu, Minus, Package,
  Plus, Search, Settings2, ShoppingBag, ShoppingCart, Sparkles, Star,
  Trash2, User, X, MessageCircle, Truck, ShieldCheck
} from "lucide-react";
import logo from "./assets/logo.jpg";

const ADMIN_PASSWORD = "omar777";
const PAYMENT_NUMBER = "01033277866";

const seedProducts = [
  {
    id: "p1",
    name: "نقاب ملكي كلاسيك",
    category: "النقاب",
    price: 180,
    oldPrice: 220,
    rating: 4.9,
    reviews: 17,
    badge: "الأكثر طلبًا",
    description: "نقاب أنيق بخامة مريحة وثبات ممتاز للاستخدام اليومي.",
    image: "product-1.svg",
    featured: true
  },
  {
    id: "p2",
    name: "خمار واسع فاخر",
    category: "الخمار",
    price: 320,
    oldPrice: 370,
    rating: 4.8,
    reviews: 12,
    badge: "جديد",
    description: "خمار واسع بانسدال هادئ ولمسة فاخرة تناسب الإطلالات المختلفة.",
    image: "product-2.svg",
    featured: true
  },
  {
    id: "p3",
    name: "دريس شرعي سادة",
    category: "الدريسات",
    price: 690,
    oldPrice: 780,
    rating: 4.9,
    reviews: 24,
    badge: "مميز",
    description: "دريس محتشم بقصة عملية، مناسب للخروج والمشاوير اليومية.",
    image: "product-3.svg",
    featured: true
  },
  {
    id: "p4",
    name: "إسدال صلاة كامل",
    category: "الإسدالات",
    price: 540,
    oldPrice: null,
    rating: 4.7,
    reviews: 8,
    badge: "",
    description: "إسدال صلاة كامل بخامة ناعمة وتصميم بسيط وأنيق.",
    image: "product-4.svg",
    featured: false
  },
  {
    id: "p5",
    name: "كولكشن مكملات الحجاب",
    category: "مكملات الحجاب",
    price: 150,
    oldPrice: 175,
    rating: 4.6,
    reviews: 9,
    badge: "عرض",
    description: "مجموعة عملية من مكملات الحجاب لإكمال إطلالتك بسهولة.",
    image: "product-5.svg",
    featured: false
  }
];

const seedReviews = [
  { id: "r1", name: "سارة", rating: 5, text: "الخامة جميلة والتغليف محترم جدًا. هكرر الطلب إن شاء الله." },
  { id: "r2", name: "مريم", rating: 5, text: "الطلب وصل بسرعة والمقاس ممتاز. التعامل راقي." },
  { id: "r3", name: "آية", rating: 4, text: "الخمار شكله أجمل على الحقيقة، ربنا يبارك لكم." }
];

const seedSettings = {
  shipping: 45,
  paymentNumber: PAYMENT_NUMBER,
  facebook: "https://www.facebook.com/profile.php?id=100094703921655"
};

const seedOrders = [];

function load(key, fallback) {
  try {
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : fallback;
  } catch {
    return fallback;
  }
}

function save(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function Money({ value }) {
  return <span>{Number(value || 0).toLocaleString("ar-EG")} ج.م</span>;
}

function Stars({ value = 5 }) {
  return (
    <span className="stars" aria-label={`تقييم ${value} من 5`}>
      {"★★★★★".slice(0, Math.round(value))}
    </span>
  );
}

function ProductImage({ src, alt }) {
  return (
    <div className="product-image">
      <img src={`/products/${src}`} alt={alt} loading="lazy" />
      <div className="image-shine" />
    </div>
  );
}

function SectionTitle({ eyebrow, title, text }) {
  return (
    <div className="section-title">
      <span>{eyebrow}</span>
      <h2>{title}</h2>
      <p>{text}</p>
    </div>
  );
}

export default function App() {
  const [products, setProducts] = useState(() => load("eg_products", seedProducts));
  const [reviews, setReviews] = useState(() => load("eg_reviews", seedReviews));
  const [orders, setOrders] = useState(() => load("eg_orders", seedOrders));
  const [settings, setSettings] = useState(() => load("eg_settings", seedSettings));
  const [cart, setCart] = useState(() => load("eg_cart", []));
  const [category, setCategory] = useState("الكل");
  const [query, setQuery] = useState("");
  const [view, setView] = useState("home");
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showCart, setShowCart] = useState(false);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [admin, setAdmin] = useState(false);
  const [toasts, setToasts] = useState([]);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [customer, setCustomer] = useState({ name: "", phone: "", address: "", notes: "", paymentRef: "" });
  const [newReview, setNewReview] = useState({ name: "", rating: 5, text: "" });

  useEffect(() => save("eg_products", products), [products]);
  useEffect(() => save("eg_reviews", reviews), [reviews]);
  useEffect(() => save("eg_orders", orders), [orders]);
  useEffect(() => save("eg_settings", settings), [settings]);
  useEffect(() => save("eg_cart", cart), [cart]);

  useEffect(() => {
    const onScroll = () => {
      const btn = document.querySelector(".to-top");
      if (btn) btn.classList.toggle("visible", window.scrollY > 500);
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const categories = ["الكل", "النقاب", "الخمار", "الدريسات", "الإسدالات", "مكملات الحجاب"];

  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      const byCat = category === "الكل" || p.category === category;
      const q = query.trim();
      const byQuery = !q || `${p.name} ${p.category} ${p.description}`.includes(q);
      return byCat && byQuery;
    });
  }, [products, category, query]);

  const cartCount = cart.reduce((sum, i) => sum + i.qty, 0);
  const cartSubtotal = cart.reduce((sum, i) => sum + i.price * i.qty, 0);
  const total = cartSubtotal + Number(settings.shipping || 0);

  function toast(message) {
    const id = crypto.randomUUID?.() || Date.now();
    setToasts(t => [...t, { id, message }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 2800);
  }

  function addToCart(product) {
    setCart(current => {
      const exists = current.find(i => i.id === product.id);
      return exists
        ? current.map(i => i.id === product.id ? { ...i, qty: i.qty + 1 } : i)
        : [...current, { ...product, qty: 1 }];
    });
    setShowCart(true);
    toast("تمت إضافة المنتج إلى السلة");
  }

  function updateQty(id, delta) {
    setCart(current =>
      current.map(i => i.id === id ? { ...i, qty: Math.max(1, i.qty + delta) } : i)
    );
  }

  function removeFromCart(id) {
    setCart(current => current.filter(i => i.id !== id));
    toast("تم حذف المنتج من السلة");
  }

  function openCategory(cat) {
    setCategory(cat);
    setView("shop");
    setTimeout(() => document.getElementById("products")?.scrollIntoView({ behavior: "smooth" }), 30);
    setMobileMenu(false);
  }

  function placeOrder(e) {
    e.preventDefault();
    if (!cart.length) return toast("السلة فارغة");
    if (!customer.name || !customer.phone || !customer.address) {
      toast("من فضلك اكملي البيانات الأساسية");
      return;
    }
    const order = {
      id: `EG-${Math.floor(100000 + Math.random() * 900000)}`,
      createdAt: new Date().toISOString(),
      customer,
      items: cart.map(i => ({ id: i.id, name: i.name, price: i.price, qty: i.qty })),
      subtotal: cartSubtotal,
      shipping: Number(settings.shipping || 0),
      total,
      status: "جديد"
    };
    setOrders(prev => [order, ...prev]);
    setCart([]);
    setCheckoutOpen(false);
    setShowCart(false);
    setCustomer({ name: "", phone: "", address: "", notes: "", paymentRef: "" });
    toast(`تم إرسال طلبك بنجاح — رقم الطلب ${order.id}`);
  }

  function submitReview(e) {
    e.preventDefault();
    if (!newReview.name.trim() || !newReview.text.trim()) {
      toast("اكتبي الاسم والتقييم أولًا");
      return;
    }
    setReviews(prev => [
      { id: crypto.randomUUID?.() || Date.now().toString(), ...newReview },
      ...prev
    ]);
    setNewReview({ name: "", rating: 5, text: "" });
    toast("شكرًا لكِ، تمت إضافة تقييمك");
  }

  return (
    <div className="app">
      <div className="gold-noise" />
      <header className="header">
        <div className="container nav">
          <button className="brand" onClick={() => { setView("home"); window.scrollTo({ top: 0, behavior: "smooth" }); }}>
            <img src={logo} alt="شعار ال جابر" />
            <span>
              <strong>ال جابر</strong>
              <small>للزي الشرعي</small>
            </span>
          </button>

          <nav className={mobileMenu ? "nav-links open" : "nav-links"}>
            <button onClick={() => { setView("home"); setMobileMenu(false); }}>الرئيسية</button>
            <button onClick={() => openCategory("الكل")}>المتجر</button>
            <button onClick={() => openCategory("النقاب")}>النقاب</button>
            <button onClick={() => openCategory("الخمار")}>الخمار</button>
            <button onClick={() => openCategory("الدريسات")}>الدريسات</button>
            <button onClick={() => document.getElementById("reviews")?.scrollIntoView({ behavior: "smooth" })}>التقييمات</button>
          </nav>

          <div className="nav-actions">
            <div className="search-mini">
              <Search size={18} />
              <input value={query} onChange={e => setQuery(e.target.value)} placeholder="ابحثي عن منتج..." />
            </div>
            <button className="icon-btn cart-btn" onClick={() => setShowCart(true)} aria-label="السلة">
              <ShoppingBag size={21} />
              {cartCount > 0 && <b>{cartCount}</b>}
            </button>
            <button className="icon-btn" onClick={() => setShowAdminLogin(true)} aria-label="الإدارة"><LayoutDashboard size={20} /></button>
            <button className="icon-btn menu-toggle" onClick={() => setMobileMenu(v => !v)} aria-label="القائمة">
              {mobileMenu ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>
      </header>

      {!admin && (
        <>
          <main>
            <section className="hero">
              <div className="hero-stars" />
              <div className="container hero-grid">
                <motion.div className="hero-copy"
                  initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .7 }}>
                  <div className="eyebrow"><Sparkles size={16} /> أناقة تليق باحتشامك</div>
                  <h1>أناقتكِ تبدأ من<br /><em>احتشامكِ</em></h1>
                  <p>تشكيلة مختارة من النقاب والخمار والدريسات والإسدالات ومكملات الحجاب، بتصميمات هادئة وخامات مختارة بعناية.</p>
                  <div className="hero-actions">
                    <button className="btn btn-gold" onClick={() => openCategory("الكل")}>تسوقي الآن <ArrowLeft size={18} /></button>
                    <a className="btn btn-ghost" href={settings.facebook} target="_blank" rel="noreferrer"><Facebook size={18} /> صفحتنا على فيسبوك</a>
                  </div>
                  <div className="trust-row">
                    <span><Truck size={17} /> شحن للعنوان</span>
                    <span><ShieldCheck size={17} /> خدمة موثوقة</span>
                    <span><CreditCard size={17} /> دفع مصاريف الشحن</span>
                  </div>
                </motion.div>

                <motion.div className="hero-card"
                  initial={{ opacity: 0, scale: .92 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: .15, duration: .8 }}>
                  <div className="ornament top" />
                  <img src={logo} alt="ال جابر للزي الشرعي" />
                  <div className="hero-card-caption">
                    <span>موسم جديد</span>
                    <h3>اختاري هدوء التفاصيل</h3>
                    <p>قطع شرعية بتفاصيل راقية.</p>
                  </div>
                  <div className="ornament bottom" />
                </motion.div>
              </div>
            </section>

            <section className="category-strip">
              <div className="container category-scroller">
                {categories.slice(1).map((cat, idx) => (
                  <button key={cat} className="category-pill" onClick={() => openCategory(cat)}>
                    <span>0{idx + 1}</span>{cat}<ArrowLeft size={15} />
                  </button>
                ))}
              </div>
            </section>

            <section className="section products-section" id="products">
              <div className="container">
                <SectionTitle
                  eyebrow="مختارات ال جابر"
                  title="تشكيلة تستحق مكانها في دولابكِ"
                  text="تصفحي أحدث القطع، اختاري المقاس المناسب، وأضيفي المفضلة إلى السلة."
                />
                <div className="shop-toolbar">
                  <div className="filters">
                    {categories.map(c => <button key={c} className={category === c ? "active" : ""} onClick={() => setCategory(c)}>{c}</button>)}
                  </div>
                  <div className="result-count">{filteredProducts.length} منتجات</div>
                </div>

                <div className="product-grid">
                  {filteredProducts.map((product, i) => (
                    <motion.article className="product-card" key={product.id}
                      initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true, amount: .2 }} transition={{ delay: i * .05 }}>
                      <button className="product-visual" onClick={() => setSelectedProduct(product)}>
                        {product.badge && <span className="badge">{product.badge}</span>}
                        <ProductImage src={product.image} alt={product.name} />
                        <span className="quick-view"><Eye size={16} /> معاينة</span>
                      </button>
                      <div className="product-info">
                        <div className="product-meta"><span>{product.category}</span><Stars value={product.rating} /></div>
                        <h3>{product.name}</h3>
                        <p>{product.description}</p>
                        <div className="price-row">
                          <div>
                            <strong><Money value={product.price} /></strong>
                            {product.oldPrice && <del><Money value={product.oldPrice} /></del>}
                          </div>
                          <button className="add-btn" onClick={() => addToCart(product)}><Plus size={18} /></button>
                        </div>
                      </div>
                    </motion.article>
                  ))}
                </div>
              </div>
            </section>

            <section className="section story-section">
              <div className="container story-grid">
                <div>
                  <span className="eyebrow">عن ال جابر</span>
                  <h2>زي شرعي بروح<br /><em>مصرية راقية</em></h2>
                  <p>نهدف لتقديم تجربة شراء سهلة ومنظمة للزي الإسلامي النسائي، مع الاهتمام بشكل المنتج وتفاصيل الطلب وخدمة العميلة من أول اختيار وحتى وصول الطلب.</p>
                  <div className="story-stats">
                    <div><b>100%</b><span>اهتمام بالتفاصيل</span></div>
                    <div><b>24/7</b><span>استقبال طلباتكِ</span></div>
                    <div><b>5★</b><span>نسعى لرضاكِ</span></div>
                  </div>
                </div>
                <div className="story-art">
                  <div className="ring ring-1" /><div className="ring ring-2" />
                  <img src={logo} alt="" />
                  <p>ال جابر<br />للزي الشرعي</p>
                </div>
              </div>
            </section>

            <section className="section reviews-section" id="reviews">
              <div className="container">
                <SectionTitle eyebrow="قالوا عنّا" title="تقييمات عميلاتنا" text="التجربة الحقيقية هي أهم جزء في أي متجر." />
                <div className="review-grid">
                  {reviews.map((r, i) => (
                    <motion.div className="review-card" key={r.id}
                      initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * .08 }}>
                      <div className="review-top"><div className="avatar">{r.name?.[0] || "ع"}</div><div><b>{r.name}</b><Stars value={r.rating} /></div></div>
                      <p>“{r.text}”</p>
                    </motion.div>
                  ))}
                </div>
                <form className="review-form" onSubmit={submitReview}>
                  <div><label>اسمكِ</label><input value={newReview.name} onChange={e => setNewReview({ ...newReview, name: e.target.value })} placeholder="مثلاً: مريم" /></div>
                  <div><label>تقييمك</label><select value={newReview.rating} onChange={e => setNewReview({ ...newReview, rating: Number(e.target.value) })}><option value="5">5 نجوم</option><option value="4">4 نجوم</option><option value="3">3 نجوم</option><option value="2">نجمتان</option><option value="1">نجمة</option></select></div>
                  <div className="grow"><label>اكتبي تجربتك</label><input value={newReview.text} onChange={e => setNewReview({ ...newReview, text: e.target.value })} placeholder="شاركي رأيكِ في الطلب..." /></div>
                  <button className="btn btn-gold" type="submit"><Star size={17} /> إرسال التقييم</button>
                </form>
              </div>
            </section>
          </main>

          <footer className="footer">
            <div className="container footer-grid">
              <div><img src={logo} alt="" /><h3>ال جابر للزي الشرعي</h3><p>الاحتشام بأناقة، والتفاصيل التي تستحقها كل إطلالة.</p></div>
              <div><h4>الأقسام</h4><button onClick={() => openCategory("النقاب")}>النقاب</button><button onClick={() => openCategory("الخمار")}>الخمار</button><button onClick={() => openCategory("الدريسات")}>الدريسات</button><button onClick={() => openCategory("الإسدالات")}>الإسدالات</button></div>
              <div><h4>تواصل</h4><a href={`https://wa.me/20${settings.paymentNumber.slice(1)}`} target="_blank" rel="noreferrer"><MessageCircle size={16} /> واتساب</a><a href={settings.facebook} target="_blank" rel="noreferrer"><Facebook size={16} /> فيسبوك</a></div>
            </div>
            <div className="footer-bottom">© {new Date().getFullYear()} ال جابر للزي الشرعي — جميع الحقوق محفوظة</div>
          </footer>
        </>
      )}

      {admin && (
        <AdminPanel
          products={products} setProducts={setProducts}
          orders={orders} setOrders={setOrders}
          reviews={reviews} setReviews={setReviews}
          settings={settings} setSettings={setSettings}
          onExit={() => setAdmin(false)}
          toast={toast}
        />
      )}

      <AnimatePresence>
        {selectedProduct && !admin && (
          <Modal onClose={() => setSelectedProduct(null)}>
            <div className="product-modal">
              <ProductImage src={selectedProduct.image} alt={selectedProduct.name} />
              <div className="modal-copy">
                <span className="eyebrow">{selectedProduct.category}</span>
                <h2>{selectedProduct.name}</h2>
                <div className="modal-rating"><Stars value={selectedProduct.rating} /> <span>{selectedProduct.reviews} تقييم</span></div>
                <p>{selectedProduct.description}</p>
                <strong className="modal-price"><Money value={selectedProduct.price} /></strong>
                <div className="modal-actions"><button className="btn btn-gold" onClick={() => { addToCart(selectedProduct); setSelectedProduct(null); }}>أضيفي للسلة <ShoppingCart size={17} /></button><button className="btn btn-ghost" onClick={() => setSelectedProduct(null)}>إغلاق</button></div>
              </div>
            </div>
          </Modal>
        )}

        {showCart && !admin && (
          <CartDrawer cart={cart} cartCount={cartCount} subtotal={cartSubtotal} shipping={settings.shipping} onClose={() => setShowCart(false)}
            updateQty={updateQty} remove={removeFromCart} onCheckout={() => { if (cart.length) setCheckoutOpen(true); else toast("السلة فارغة"); }} />
        )}

        {checkoutOpen && !admin && (
          <Modal onClose={() => setCheckoutOpen(false)}>
            <form className="checkout" onSubmit={placeOrder}>
              <div className="checkout-head"><div><span className="eyebrow">إتمام الطلب</span><h2>بيانات التوصيل والدفع</h2></div><Package size={30} /></div>
              <div className="order-summary">
                <div><span>المنتجات</span><b><Money value={cartSubtotal} /></b></div>
                <div><span>مصاريف الشحن</span><b><Money value={settings.shipping} /></b></div>
                <div className="grand"><span>الإجمالي</span><b><Money value={total} /></b></div>
              </div>
              <div className="payment-note"><CreditCard size={18} /><div><b>مصاريف الشحن تُدفع على الرقم</b><strong>{settings.paymentNumber}</strong><small>بعد التحويل، اكتبي رقم/مرجع التحويل في الخانة التالية.</small></div></div>
              <div className="form-grid">
                <label>الاسم<input required value={customer.name} onChange={e => setCustomer({ ...customer, name: e.target.value })} /></label>
                <label>رقم الهاتف<input required inputMode="tel" value={customer.phone} onChange={e => setCustomer({ ...customer, phone: e.target.value })} /></label>
                <label className="wide">العنوان بالتفصيل<input required value={customer.address} onChange={e => setCustomer({ ...customer, address: e.target.value })} /></label>
                <label>مرجع التحويل<input value={customer.paymentRef} onChange={e => setCustomer({ ...customer, paymentRef: e.target.value })} placeholder="اختياري" /></label>
                <label>ملاحظات<input value={customer.notes} onChange={e => setCustomer({ ...customer, notes: e.target.value })} placeholder="مثلاً: لون أو وقت مناسب" /></label>
              </div>
              <div className="modal-actions"><button className="btn btn-gold" type="submit">تأكيد الطلب <CheckCircle2 size={18} /></button><button className="btn btn-ghost" type="button" onClick={() => setCheckoutOpen(false)}>رجوع</button></div>
            </form>
          </Modal>
        )}

        {showAdminLogin && (
          <Modal onClose={() => setShowAdminLogin(false)}>
            <form className="admin-login" onSubmit={e => { e.preventDefault(); const p = new FormData(e.currentTarget).get("password"); if (p === ADMIN_PASSWORD) { setAdmin(true); setShowAdminLogin(false); toast("تم تسجيل دخول لوحة الإدارة"); } else toast("كلمة السر غير صحيحة"); }}>
              <img src={logo} alt="" />
              <span className="eyebrow">لوحة الإدارة</span>
              <h2>مرحبًا بكِ في إدارة المتجر</h2>
              <p>أدخلي كلمة السر للوصول إلى المنتجات والطلبات والتقييمات.</p>
              <input name="password" type="password" autoFocus placeholder="كلمة السر" />
              <button className="btn btn-gold" type="submit">دخول <ArrowLeft size={17} /></button>
              <small>نسخة التطوير: كلمة السر مضبوطة داخل المشروع. قبل النشر العام يُنصح بربط المصادقة بقاعدة بيانات آمنة.</small>
            </form>
          </Modal>
        )}
      </AnimatePresence>

      <button className="to-top" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} aria-label="إلى الأعلى"><ArrowUp size={18} /></button>
      <div className="toast-stack">{toasts.map(t => <motion.div key={t.id} className="toast" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 12 }}><CheckCircle2 size={17} />{t.message}</motion.div>)}</div>
    </div>
  );
}

function Modal({ children, onClose }) {
  return (
    <motion.div className="modal-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <motion.div className="modal-shell" initial={{ opacity: 0, y: 30, scale: .97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 20, scale: .98 }}>
        <button className="modal-close" onClick={onClose}><X size={19} /></button>
        {children}
      </motion.div>
    </motion.div>
  );
}

function CartDrawer({ cart, cartCount, subtotal, shipping, onClose, updateQty, remove, onCheckout }) {
  return (
    <motion.div className="drawer-layer" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <div className="drawer-overlay" onClick={onClose} />
      <motion.aside className="cart-drawer" initial={{ x: 420 }} animate={{ x: 0 }} exit={{ x: 420 }}>
        <div className="drawer-head"><div><span>سلتكِ</span><h2>{cartCount} قطعة</h2></div><button className="icon-btn" onClick={onClose}><X size={20} /></button></div>
        <div className="cart-items">
          {cart.length === 0 && <div className="empty-state"><ShoppingBag size={34} /><h3>السلة فاضية</h3><p>ضيفي أول قطعة تعجبكِ.</p></div>}
          {cart.map(i => (
            <div className="cart-item" key={i.id}>
              <img src={`/products/${i.image}`} alt="" />
              <div className="cart-item-main"><b>{i.name}</b><span>{i.category}</span><strong><Money value={i.price * i.qty} /></strong>
                <div className="qty"><button onClick={() => updateQty(i.id, -1)}><Minus size={13} /></button><b>{i.qty}</b><button onClick={() => updateQty(i.id, 1)}><Plus size={13} /></button><button className="trash" onClick={() => remove(i.id)}><Trash2 size={14} /></button></div>
              </div>
            </div>
          ))}
        </div>
        {cart.length > 0 && <div className="drawer-foot"><div><span>قيمة المنتجات</span><b><Money value={subtotal} /></b></div><div><span>الشحن</span><b><Money value={shipping} /></b></div><div className="drawer-total"><span>الإجمالي</span><b><Money value={subtotal + shipping} /></b></div><button className="btn btn-gold wide-btn" onClick={onCheckout}>إتمام الطلب <ArrowLeft size={17} /></button></div>}
      </motion.aside>
    </motion.div>
  );
}

function AdminPanel({ products, setProducts, orders, setOrders, reviews, setReviews, settings, setSettings, onExit, toast }) {
  const [tab, setTab] = useState("dashboard");
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name: "", category: "النقاب", price: "", oldPrice: "", rating: 5, reviews: 0, badge: "جديد", description: "", image: "product-1.svg", featured: false });

  function startNew() {
    setEditing("new");
    setForm({ name: "", category: "النقاب", price: "", oldPrice: "", rating: 5, reviews: 0, badge: "جديد", description: "", image: "product-1.svg", featured: false });
  }
  function startEdit(p) {
    setEditing(p.id);
    setForm(p);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  function saveProduct(e) {
    e.preventDefault();
    if (!form.name || !form.price) return toast("اكتبي اسم المنتج والسعر");
    if (editing === "new") {
      setProducts(prev => [{ ...form, id: crypto.randomUUID?.() || Date.now().toString(), price: Number(form.price), oldPrice: form.oldPrice ? Number(form.oldPrice) : null }, ...prev]);
      toast("تمت إضافة المنتج");
    } else {
      setProducts(prev => prev.map(p => p.id === editing ? { ...form, id: editing, price: Number(form.price), oldPrice: form.oldPrice ? Number(form.oldPrice) : null } : p));
      toast("تم حفظ المنتج");
    }
    setEditing(null);
  }

  const newOrders = orders.filter(o => o.status === "جديد").length;
  const revenue = orders.filter(o => o.status !== "ملغي").reduce((s, o) => s + Number(o.total || 0), 0);

  return (
    <main className="admin-page">
      <div className="container admin-wrap">
        <div className="admin-topbar">
          <div className="admin-brand"><img src={logo} alt="" /><div><span>إدارة المتجر</span><h1>ال جابر للزي الشرعي</h1></div></div>
          <div className="admin-actions"><button className="btn btn-ghost" onClick={onExit}>العودة للمتجر</button></div>
        </div>

        <div className="admin-layout">
          <aside className="admin-side">
            {[
              ["dashboard", "نظرة عامة", LayoutDashboard],
              ["products", "المنتجات", Package],
              ["orders", "الطلبات", ShoppingCart],
              ["reviews", "التقييمات", Star],
              ["settings", "الإعدادات", Settings2]
            ].map(([key, label, Icon]) => <button key={key} className={tab === key ? "active" : ""} onClick={() => setTab(key)}><Icon size={18} />{label}</button>)}
          </aside>

          <section className="admin-content">
            {tab === "dashboard" && <div>
              <div className="section-title admin-heading"><span>اليوم</span><h2>نظرة عامة</h2><p>إدارة سريعة للمتجر والطلبات.</p></div>
              <div className="stats-grid">
                <div className="stat-card"><Package size={22} /><span>المنتجات</span><b>{products.length}</b></div>
                <div className="stat-card"><ShoppingCart size={22} /><span>كل الطلبات</span><b>{orders.length}</b></div>
                <div className="stat-card"><Clock3 size={22} /><span>طلبات جديدة</span><b>{newOrders}</b></div>
                <div className="stat-card"><CreditCard size={22} /><span>إجمالي الطلبات</span><b><Money value={revenue} /></b></div>
              </div>
              <div className="admin-card">
                <div className="admin-card-head"><h3>آخر الطلبات</h3><button onClick={() => setTab("orders")}>عرض الكل <ArrowLeft size={15} /></button></div>
                {orders.slice(0, 5).map(o => <OrderRow key={o.id} order={o} onStatus={(status) => setOrders(prev => prev.map(x => x.id === o.id ? { ...x, status } : x))} />)}
                {!orders.length && <div className="empty-admin">لا توجد طلبات حتى الآن.</div>}
              </div>
            </div>}

            {tab === "products" && <div>
              <div className="admin-heading-row"><div className="section-title admin-heading"><span>كتالوجك</span><h2>المنتجات</h2></div><button className="btn btn-gold" onClick={startNew}><Plus size={17} /> منتج جديد</button></div>
              <div className="admin-card table-card">
                <table><thead><tr><th>المنتج</th><th>القسم</th><th>السعر</th><th>التقييم</th><th>إجراءات</th></tr></thead>
                <tbody>{products.map(p => <tr key={p.id}><td><div className="table-product"><img src={`/products/${p.image}`} alt="" /><b>{p.name}</b></div></td><td>{p.category}</td><td><Money value={p.price} /></td><td>{p.rating} ★</td><td><button className="table-btn" onClick={() => startEdit(p)}>تعديل</button><button className="table-btn danger" onClick={() => { setProducts(prev => prev.filter(x => x.id !== p.id)); toast("تم حذف المنتج"); }}>حذف</button></td></tr>)}</tbody></table>
              </div>
              {editing && <form className="admin-card product-editor" onSubmit={saveProduct}><div className="admin-card-head"><h3>{editing === "new" ? "إضافة منتج" : "تعديل المنتج"}</h3><button type="button" onClick={() => setEditing(null)}>إلغاء</button></div><div className="form-grid"><label>اسم المنتج<input required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></label><label>القسم<select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>{categories.map(c => c !== "الكل" && <option key={c}>{c}</option>)}</select></label><label>السعر<input required type="number" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} /></label><label>السعر قبل الخصم<input type="number" value={form.oldPrice || ""} onChange={e => setForm({ ...form, oldPrice: e.target.value })} /></label><label>صورة المنتج<select value={form.image} onChange={e => setForm({ ...form, image: e.target.value })}><option>product-1.svg</option><option>product-2.svg</option><option>product-3.svg</option><option>product-4.svg</option><option>product-5.svg</option></select></label><label>الشارة<input value={form.badge} onChange={e => setForm({ ...form, badge: e.target.value })} placeholder="جديد / عرض / الأكثر طلبًا" /></label><label className="wide">الوصف<input value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} /></label></div><button className="btn btn-gold" type="submit">حفظ المنتج <CheckCircle2 size={17} /></button></form>}
            </div>}

            {tab === "orders" && <div><div className="section-title admin-heading"><span>المبيعات</span><h2>الطلبات</h2><p>راجعي بيانات العميلة وحالة الشحن لكل طلب.</p></div><div className="orders-stack">{orders.map(o => <OrderRow key={o.id} order={o} expanded onStatus={(status) => setOrders(prev => prev.map(x => x.id === o.id ? { ...x, status } : x))} />)}{!orders.length && <div className="admin-card empty-admin">لا توجد طلبات حتى الآن.</div>}</div></div>}

            {tab === "reviews" && <div><div className="section-title admin-heading"><span>آراء العميلات</span><h2>التقييمات</h2></div><div className="review-admin-grid">{reviews.map(r => <div className="review-admin" key={r.id}><div><b>{r.name}</b><Stars value={r.rating} /></div><p>{r.text}</p><button className="table-btn danger" onClick={() => { setReviews(prev => prev.filter(x => x.id !== r.id)); toast("تم حذف التقييم"); }}>حذف</button></div>)}</div></div>}

            {tab === "settings" && <div><div className="section-title admin-heading"><span>التحكم</span><h2>إعدادات المتجر</h2><p>القيم هنا تُستخدم مباشرة في واجهة المتجر وسلة الشراء.</p></div><form className="admin-card settings-form" onSubmit={e => { e.preventDefault(); toast("تم حفظ الإعدادات"); }}><label>مصاريف الشحن (ج.م)<input type="number" value={settings.shipping} onChange={e => setSettings({ ...settings, shipping: Number(e.target.value) })} /></label><label>رقم دفع مصاريف الشحن<input inputMode="tel" value={settings.paymentNumber} onChange={e => setSettings({ ...settings, paymentNumber: e.target.value })} /></label><label>رابط فيسبوك<input value={settings.facebook} onChange={e => setSettings({ ...settings, facebook: e.target.value })} /></label><button className="btn btn-gold" type="submit">حفظ الإعدادات</button></form><div className="admin-card security-note"><ShieldCheck size={20} /><div><b>تنبيه أمني قبل النشر</b><p>نسخة VS Code الحالية تحفظ البيانات محليًا في المتصفح لأغراض التطوير. للنشر الحقيقي، اربطي المنتجات والطلبات والتقييمات بقاعدة بيانات ومصادقة خادم/ Supabase بدل localStorage.</p></div></div></div>}
          </section>
        </div>
      </div>
    </main>
  );
}

function OrderRow({ order, expanded = false, onStatus }) {
  return (
    <div className={`order-row ${expanded ? "expanded" : ""}`}>
      <div className="order-main"><div><span className="order-id">{order.id}</span><b>{order.customer.name}</b><small>{order.customer.phone}</small></div><strong><Money value={order.total} /></strong><select value={order.status} onChange={e => onStatus(e.target.value)}><option>جديد</option><option>تم التأكيد</option><option>جاري التجهيز</option><option>تم الشحن</option><option>مكتمل</option><option>ملغي</option></select></div>
      {expanded && <div className="order-details"><div><b>العنوان:</b> {order.customer.address}</div><div><b>مرجع التحويل:</b> {order.customer.paymentRef || "—"}</div><div><b>الملاحظات:</b> {order.customer.notes || "—"}</div><div><b>المنتجات:</b> {order.items.map(i => `${i.name} × ${i.qty}`).join("، ")}</div><div className="order-breakdown"><span>المنتجات <Money value={order.subtotal} /></span><span>الشحن <Money value={order.shipping} /></span></div></div>}
    </div>
  );
}

const categories = ["الكل", "النقاب", "الخمار", "الدريسات", "الإسدالات", "مكملات الحجاب"];
